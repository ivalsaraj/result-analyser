<?php
if(isset($clg))
{
	echo form_open('result/mycollege');
	echo "<table><tr><td>";
	echo "<select name='college'  class='form-control'>";
	echo "<option value='-1'>Select your College</option>";
	foreach($clg->result() as $c)
	{
		echo "<option value='".$c->cid."'>".$c->cname."</option>";
	}
	echo "</td><td><input type='submit' value='Get Result' name='submit' class='btn btn-primary'/></td></tr></table>";
	echo '</form>';
}
?>
		<div class="callout callout-info">
                    <h4>Click Table header to sort !</h4>
                    <p>eg: click register number to sort register number wise, click again to sort in descending order.
		</p>
		</div>
<?php
if(isset($result) && !empty($result))
{
	$sl=isset($clg)?"Sl.No.":"Rank";
	$values=array($sl,"Register Number","Name","Course","College","MFCS","DS","CO","PM","C","C Lab","PCH Lab","English");
	$i=13;
	$values[$i++]="Total";
	$values[$i++]="Pass/Fail";
	$values[$i++]='Percentage';
	$i=0;
	$f=0;
	if(isset($clg))
	echo '<div class="alert alert-danger alert-dismissable">
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">x</button>
                    <h4><i class="icon fa fa-info">#</i> College Name:
                  '.$result->row()->cname.' </h4> Total Students : '.$result->num_rows().' </div>';
	echo "<table class='table table-hover table-bordered tablesort dataTable'><thead><tr>";
	foreach($values as $v)
		echo "<th>".$v."</th>";
	echo "</thead>";
	$j=1;
	foreach($result->result() as $res)
	{ //print_r($res);
			if($res->pass=='F') $f++;
	echo "<tr><td>".$j++."</td>";
	foreach($res as $v)
		echo "<td>".$v."</td>";
	echo "</tr>";
	}
	echo "</table>";
	echo $f;
	}
?>
<script>
$(function(){
  $(".tablesort").tablesorter();
  $('.tablesort').filterTable();
});
</script>
<style>
.filter-table .quick { margin-left: 0.5em; font-size: 0.8em; text-decoration: none; }
.fitler-table .quick:hover { text-decoration: underline; }
td.alt {
    background-color: rgba(24, 242, 169, 0.57);
}
</style>